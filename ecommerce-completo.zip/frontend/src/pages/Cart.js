import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Cart() {
  return (
    <div>
      <Navbar />
      <div className="p-6">
        <h2 className="text-2xl text-gold mb-4">Seu Carrinho</h2>
        <div className="bg-dark border border-gold p-4 rounded">
          <p className="text-white">1x Produto Exemplo - R$ 199,90</p>
          <button className="bg-gold text-black px-4 py-2 mt-2 rounded">Finalizar Compra</button>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Cart;