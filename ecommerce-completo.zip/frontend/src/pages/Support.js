import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Support() {
  return (
    <div>
      <Navbar />
      <div className="p-6 max-w-xl mx-auto">
        <h2 className="text-2xl text-gold mb-4">Suporte</h2>
        <p className="text-white mb-4">Precisa de ajuda? Estamos aqui para você!</p>
        <ul className="list-disc ml-6 text-white">
          <li>Envie um e-mail para suporte@empresa.com</li>
          <li>Atendimento de segunda à sexta, das 9h às 18h</li>
        </ul>
      </div>
      <Footer />
    </div>
  );
}

export default Support;