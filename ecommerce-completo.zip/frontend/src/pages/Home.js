import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Home() {
  return (
    <div>
      <Navbar />
      <main className="p-6">
        <h1 className="text-3xl text-gold mb-4">Bem-vindo à Loja Empresarial</h1>
        <p className="text-white">Aqui você encontra os melhores produtos com um design exclusivo.</p>
      </main>
      <Footer />
    </div>
  );
}

export default Home;