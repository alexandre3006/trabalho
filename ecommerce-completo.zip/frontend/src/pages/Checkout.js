import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Checkout() {
  return (
    <div>
      <Navbar />
      <div className="p-6 max-w-xl mx-auto">
        <h2 className="text-2xl text-gold mb-4">Pagamento</h2>
        <form className="flex flex-col gap-4">
          <input type="text" placeholder="Nome no Cartão / CPF Pix" className="p-2 rounded" />
          <select className="p-2 rounded">
            <option value="cartao">Cartão de Crédito</option>
            <option value="pix">Pix</option>
          </select>
          <button className="bg-gold text-black p-2 rounded">Pagar</button>
        </form>
      </div>
      <Footer />
    </div>
  );
}

export default Checkout;