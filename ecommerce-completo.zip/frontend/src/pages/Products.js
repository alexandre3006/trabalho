import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function ProductPage() {
  return (
    <div>
      <Navbar />
      <div className="p-6">
        <h2 className="text-2xl text-gold mb-4">Produtos</h2>
        <div className="mb-4">
          <input type="text" placeholder="Buscar..." className="p-2 rounded w-full max-w-md" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-dark border border-gold p-4 rounded">
            <img src="https://via.placeholder.com/200" alt="Produto" className="w-full rounded"/>
            <h3 className="text-lg text-white mt-2">Nome do Produto</h3>
            <p className="text-gold">R$ 199,90</p>
            <button className="bg-gold text-black px-4 py-2 mt-2 rounded">Adicionar ao Carrinho</button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default ProductPage;