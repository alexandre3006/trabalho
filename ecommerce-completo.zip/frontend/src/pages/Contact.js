import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Contact() {
  return (
    <div>
      <Navbar />
      <div className="p-6 max-w-xl mx-auto">
        <h2 className="text-2xl text-gold mb-4">Fale Conosco</h2>
        <form className="flex flex-col gap-4">
          <input type="text" placeholder="Nome" className="p-2 rounded" />
          <input type="email" placeholder="Email" className="p-2 rounded" />
          <textarea placeholder="Mensagem" className="p-2 rounded h-32"></textarea>
          <button className="bg-gold text-black p-2 rounded">Enviar</button>
        </form>
      </div>
      <Footer />
    </div>
  );
}

export default Contact;