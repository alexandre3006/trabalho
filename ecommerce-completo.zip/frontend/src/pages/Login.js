import React from "react";
import Navbar from "../components/Navbar";

function Login() {
  return (
    <div>
      <Navbar />
      <div className="p-6 max-w-md mx-auto">
        <h2 className="text-2xl text-gold mb-4">Entrar</h2>
        <form className="flex flex-col gap-4">
          <input type="email" placeholder="Email" className="p-2 rounded" />
          <input type="password" placeholder="Senha" className="p-2 rounded" />
          <button className="bg-gold text-black p-2 rounded">Entrar</button>
        </form>
      </div>
    </div>
  );
}

export default Login;