import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="bg-copper p-4 flex justify-between items-center">
      <Link to="/" className="text-gold font-bold text-xl">Loja Empresarial</Link>
      <div className="flex gap-4">
        <Link to="/login" className="text-white">Login</Link>
        <Link to="/register" className="text-white">Cadastro</Link>
        <Link to="/cart" className="text-white">Carrinho</Link>
      </div>
    </nav>
  );
}

export default Navbar;