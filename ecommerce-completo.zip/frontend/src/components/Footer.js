import React from "react";

function Footer() {
  return (
    <footer className="bg-copper text-center p-4 mt-8 text-white">
      © 2025 Loja Empresarial - Todos os direitos reservados.
    </footer>
  );
}

export default Footer;