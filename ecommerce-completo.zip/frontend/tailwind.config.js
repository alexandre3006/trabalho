module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        copper: '#B87333',
        gold: '#FFD700',
        dark: '#1a1a1a'
      }
    }
  },
  plugins: [],
}